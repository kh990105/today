export default function myFunc(name, age) {
    return `안녕${name}, 너의 나이는 ${age} 이구나.`;
}