import myFunc from './script.js';
console.log(myFunc('영희' ,19)
);